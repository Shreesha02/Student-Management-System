package com.example.studentmanagement.service;

import java.util.List;

import com.example.studentmanagement.model.Admin;


public interface AdminService {
	Admin saveAdmin(Admin admin);
	Admin loginAdmin(Admin admin);
	List<Admin> getAllAdmin();
	
}

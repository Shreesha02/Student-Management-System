package com.example.studentmanagement.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.studentmanagement.exception.ResourseNotFoundException;
import com.example.studentmanagement.model.Trainer;
import com.example.studentmanagement.repository.TrainerRepository;
import com.example.studentmanagement.service.TrainerService;

@Service
public class TrainerServiceImpl implements TrainerService{
@Autowired
TrainerRepository trainerRepository;


public TrainerServiceImpl(TrainerRepository trainerRepository) {
	super();
	this.trainerRepository = trainerRepository;
	
}

@Override
public Trainer saveTrainer(Trainer trainer) {
	
	return trainerRepository.save(trainer);
}

@Override
public Trainer loginTrainer(Trainer trainer) {
	return trainerRepository.findByEmailIDAndPassword(trainer.emailID,trainer.password).orElseThrow(()->new ResourseNotFoundException("Trainer", "Id",trainer.emailID+" and password "+trainer.password ));
}

@Override
public List<Trainer> getAllTrainers() {
	
	return trainerRepository.findAll();
}

@Override
public Trainer getTrainerById(long trainerId) {
	
	return trainerRepository.findById(trainerId).orElseThrow(()->new ResourseNotFoundException("Trainer", "Id",trainerId));
}

@Override
public Trainer updateTrainer(Trainer trainer, long trainerId) 
{
	Trainer trainer1=trainerRepository.findById(trainerId).orElseThrow(()->new ResourseNotFoundException("Trainer", "Id",trainerId));
	trainer1.setFirstName(trainer.getFirstName());
	trainer1.setLastName(trainer.getLastName());
	trainer1.setPhoneNumber(trainer.getPhoneNumber());
	trainer1.setEmailID(trainer.getEmailID());
	trainer1.setPassword(trainer.getPassword());
	return trainerRepository.save(trainer1);
}

@Override
public Trainer getTrainerByEmail(Trainer trainer) {
	
	return trainerRepository.findByEmailID(trainer.emailID).orElseThrow(()->new ResourseNotFoundException("Trainer", "Email",trainer.emailID));
}

@Override
public void deleteTrainer(long trainerId) {
	
	trainerRepository.findById(trainerId).orElseThrow(()->new ResourseNotFoundException("Trainer", "Id",trainerId));
	trainerRepository.deleteById(trainerId);
}

}
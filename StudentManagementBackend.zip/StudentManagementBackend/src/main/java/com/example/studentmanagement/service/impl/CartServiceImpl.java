package com.example.studentmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.studentmanagement.exception.ResourseNotFoundException;
import com.example.studentmanagement.model.Cart;
import com.example.studentmanagement.model.Course;
import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.CartRepository;

import com.example.studentmanagement.service.CartService;
import com.example.studentmanagement.service.CourseService;
import com.example.studentmanagement.service.StudentService;
@Service
public class CartServiceImpl implements CartService{
	@Autowired
	private CartRepository cartRepository;
	@Autowired
	private CourseService courseService;
	private StudentService studentService;
	
	public CartServiceImpl(CartRepository cartRepository, CourseService courseService, StudentService studentService) {
		super();
		this.cartRepository = cartRepository;
		this.courseService = courseService;
		this.studentService = studentService;
	}

	@Override
	public Cart saveCart(Cart cart) 
	{
		return cartRepository.save(cart);
	}
	
	@Override
	public Cart addCourseToCart(Cart cart, long courseId, long studentId)
	{
		 Course course=courseService.getCourseById(courseId);
		 Student student =studentService.getStudentById(studentId);
		 cart.setCourse(course);
		 cart.setStudent(student);
		 return cartRepository.save(cart);
	}

	@Override
	public List<Cart> getCartByStudentId(long studentId) 
	{
		return  cartRepository.findByStudentStudentId(studentId);
	}
	

	@Override
	public List<Cart> getCartById() 
	{
		return cartRepository.findAll();
	}

	@Override
	public Cart getCartById(long cartId) 
	{
		return cartRepository.findById(cartId).orElseThrow(()-> new ResourseNotFoundException("Cart", "cartId",cartId ));
	}

	@Override
	public void deleteCart(long cartId) 
	{
		cartRepository.findById(cartId).orElseThrow(()-> new ResourseNotFoundException("cart", "cartId", cartId));
		cartRepository.deleteById(cartId);
	}

	
	
	

	/*
	 
	 @Override 
	 public Cart addCourseToCart(Cart cart, long courseId, StringstudentEmailId) 
	 {  
	 Course course=courseService.getCourseById(courseId); 
	 Student student =studentService.getStudentByEmailId(studentEmailId); 
	 cart.setCourse(course);
	  cart.setStudent(student);
	   return cartRepository.save(cart);
	  
	  }
	  
	  @Override public List<Cart> getCartByStudentEmailId(String studentEmailID) {
	  // TODO Auto-generated method stub return
	  cartRepository.findByStudentEmailID(studentEmailID); }
	 */

	
	

	

	

	

	/*
	 * @Override public List<Cart> getCartByStudentId(long studentId) { // TODO
	 * Auto-generated method stub return cartRepository.findByStudentId(studentId);
	 * }
	 */

}

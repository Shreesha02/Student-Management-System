package com.example.studentmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.studentmanagement.model.Cart;

import com.example.studentmanagement.service.CartService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api/cart")
public class CartController {
	@Autowired
	private CartService cartService;

	public CartController(CartService cartService) {
		super();
		this.cartService = cartService;
	}
	
	//Adding to Course Cart
	@PostMapping("/add")
	public ResponseEntity<Cart> addCart(@RequestBody Cart cart)
	{
		return new ResponseEntity<Cart>(cartService.saveCart(cart),HttpStatus.CREATED);
	}
	
	@PostMapping("/add/{courseId}/{studentId}")
	public ResponseEntity <Cart> addCourseToStudent( @RequestBody Cart cart,@PathVariable("courseId") long courseId,@PathVariable("studentId") long studentId)
	{
		return new ResponseEntity<Cart> (cartService.addCourseToCart(cart, courseId, studentId), HttpStatus.CREATED);
	}
	
	//Getting the list of Course Added in the Cart
	@GetMapping
	public List<Cart> getCart()
	{
		return cartService.getCartById();
	}
	
	//to get the cart by studentId
	  
	 @GetMapping("/student/{studentId}") 
	 public List<Cart> getCartByStudentId(@PathVariable ("studentId") long studentId) 
	 { 
	     return cartService.getCartByStudentId(studentId); 
	 }
	 
	//Delete Food
		@DeleteMapping("{cartId}")
		public ResponseEntity<String> deleteCart(@PathVariable("cartId") long cartId)
		{
			cartService.deleteCart(cartId);
			return new ResponseEntity<String> ("CART deleted Successfully: " + cartId ,HttpStatus.OK);
		}
	
	
	/*@PostMapping("/add/{courseId}/{studentEmailId}")
	public ResponseEntity <Cart> addCourseToStudent( @RequestBody Cart cart,@PathVariable("courseId") long courseId,@PathVariable("studentEmailId") String studentEmailId)
	{
		return new ResponseEntity<Cart> (cartService.addCourseToCart(cart, courseId, studentEmailId), HttpStatus.CREATED);
	}
	
	
	
	
	
	@GetMapping("/student/{studentEmailId}")
	public List<Cart> getCartByStudentEmailId(@PathVariable ("studentEmailId")String studentEmailId)
	{
		return  cartService.getCartByStudentEmailId(studentEmailId);
	}*/
	
	
}

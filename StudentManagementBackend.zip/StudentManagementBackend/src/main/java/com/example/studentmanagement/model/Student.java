package com.example.studentmanagement.model;


import java.util.List;
//import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Student_Table")
@SequenceGenerator(name = "studentId_gen",initialValue = 20201)
public class Student {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "studentId_gen")
	
	@Column(name = "Student_Id")
    private long studentId;
 
	@Column(name="First_Name")
	@NotEmpty
	@Size(min=3 , message="firstName must contain atleast 3 characters")
	private String firstName;
	
	@Column(name="Last_Name")
	@NotEmpty
	@Size(min=3 , message="lastName must contain atleast 3 characters")
	private String lastName;
	
	@Column(name="Gender")
	@NotEmpty
	@Size(min=4 , message="gender must contain atleast 4 characters")
	public String gender;
	
	@Column(name="Phone_Number")
	@NotEmpty
	@Size(min=10 ,max=10, message="phoneNumber must contain  10 digits")
	private String phoneNumber;
	
	@Column(name="Address")
	@NotEmpty
	private String address;
	
	@Column(name="District")
	@NotEmpty
	@Size(min=3 , message="district must contain atleast 3 characters")
    private String district;
	
	@Column(name="pin_code")
	@NotEmpty
	@Size(min=6 ,max=6, message="PinCode must contain 6 digits")
	private String pinCode;
	
	@Column(name="State")
	@NotEmpty
	@Size(min=3 , message="State must contain atleast 3 characters")
    private String state;
	
	@Column(name="Country")
	@NotEmpty
	@Size(min=3 , message="state must contain atleast 3 characters")
    private String country;
	
	@Column(name="Email_Id",unique=true)
	@NotEmpty
	@Email(message="Email is not valid!")
	public String emailID;
	
	@Column(name="Password")
	@NotEmpty
	@Size(min=8, message="Password length must be 5 and contain uppercase,lowercase,digits")
	@Pattern(regexp="(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}")
    public String password;

	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.PERSIST)
    @JoinTable(name = "students_courses_table",
            joinColumns = {
                    @JoinColumn(name = "student_id")},
            inverseJoinColumns = {
                    @JoinColumn(name = "course_id")})
      private List<Course> courses;
	
	@OneToMany(mappedBy="student", cascade=CascadeType.MERGE)
    @JsonIgnore
	private List<Payment>payment;
    
    public Student(){
    	
    }
   
    public long getStudentId() {
		return studentId;
	}




	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}




	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	
    public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	
	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Course> getCourses() {
		return courses;
	}

	public void setCourses(List<Course> courses) {
		this.courses = courses;
	}

	public List<Payment> getPayment() {
		return payment;
	}

	public void setPayment(List<Payment> payment) {
		this.payment = payment;
	}

}

package com.example.studentmanagement.model;


import java.util.HashSet;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Course_Table")

public class Course {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator ="courseId_gen")
	@SequenceGenerator(name = "courseId_gen",sequenceName="course_Sequence",initialValue = 1001,allocationSize=1 )
	@Column(name="Course_Id")
	private long courseId;

	@Column(name="Course_Name")
	private String courseName;

	@Column(name="Course_Fees")
	private int courseFees;

	@Column(name="Course_Duration")
	private String courseDuration;
	
	
	@ManyToMany
	@JoinTable(name = "students_courses_table",
    joinColumns =  @JoinColumn(name = "courseId"),
    inverseJoinColumns = @JoinColumn(name = "studentId"))
	private Set <Student> students = new HashSet<>();
	
	@JsonIgnore//when it is displaying the course object it doesn't display the trainer so @jsonIgnore annotation
	@ManyToOne(cascade = CascadeType.ALL)
    private Trainer trainer;
	
	

	public long getCourseId() {
		return courseId;
	}

	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public int getCourseFees() {
		return courseFees;
	}

	public void setCourseFees(int courseFees) {
		this.courseFees = courseFees;
	}

	public String getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(String courseDuration) {
		this.courseDuration = courseDuration;
	}

	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

	
	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}

	public void enrollStudent(Student student) {
		students.add(student);
	}
	
	public void assignTrainer(Trainer trainer) {
		this.trainer=trainer;
	}

	

	}

package com.example.studentmanagement.model;


import java.util.List;
//import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Course_Table")
@SequenceGenerator(name = "courseId_gen",initialValue = 1001)
public class Course {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO, generator ="courseId_gen")
	@Column(name="Course_Id")
	private long courseId;

	@Column(name="Course_Name")
	private String courseName;

	@Column(name="Course_Fees")
	private int courseFees;

	@Column(name="Course_Duration")
	private String courseDuration;
	
	@ManyToMany(mappedBy = "courses", fetch = FetchType.LAZY)
	@JsonIgnore
    private List <Student> students ;
	
	@OneToMany(mappedBy="course", cascade=CascadeType.MERGE)
    @JsonIgnore
	private List<Trainer>trainer;

	public long getCourseId() {
		return courseId;
	}

	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	

	public int getCourseFees() {
		return courseFees;
	}

	public void setCourseFees(int courseFees) {
		this.courseFees = courseFees;
	}

	public String getCourseDuration() {
		return courseDuration;
	}

	public void setCourseDuration(String courseDuration) {
		this.courseDuration = courseDuration;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}

	public List<Trainer> getTrainer() {
		return trainer;
	}

	public void setTrainer(List<Trainer> trainer) {
		this.trainer = trainer;
	}

	

	

	
}

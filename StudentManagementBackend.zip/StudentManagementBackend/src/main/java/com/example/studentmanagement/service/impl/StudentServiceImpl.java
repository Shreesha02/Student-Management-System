package com.example.studentmanagement.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.studentmanagement.exception.ResourseNotFoundException;

import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.StudentRepository;
import com.example.studentmanagement.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{
@Autowired	
StudentRepository  studentRepository; 

	
	public StudentServiceImpl(StudentRepository studentRepository) {
		super();
		this.studentRepository = studentRepository;
	}


	@Override
	public Student saveStudent(Student student) {
		// TODO Auto-generated method stub
		return studentRepository.save(student);
	}


	@Override
	public Student loginStudent(Student student) {
		return studentRepository.findByEmailIDAndPassword(student.emailID,student.password).orElseThrow(()->new ResourseNotFoundException("Student", "Id",student.emailID+" and password "+student.password ));
	}


	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return studentRepository.findAll();
	}


	@Override
	public Student getStudentById(long studentId) {
		// TODO Auto-generated method stub
		return studentRepository.findById(studentId).orElseThrow(()->new ResourseNotFoundException("Student","Id",studentId));
	}


	@Override
	public Student updateStudent(Student student, long studentId) {
		// TODO Auto-generated method stub;
		Student student1 = getStudentById(studentId);
		student1.setFirstName(student.getFirstName());
		student1.setLastName(student.getLastName());
		student1.setGender(student.getGender());
		student1.setPhoneNumber(student.getPhoneNumber());
		student1.setAddress(student.getAddress());
		student1.setDistrict(student.getDistrict());
		student1.setPinCode(student.getPinCode());
		student1.setState(student.getState());
		student1.setCountry(student.getCountry());
		student1.setEmailID(student.getEmailID());
		student1.setPassword(student.getPassword());
		return studentRepository.save(student);
	}
	
   @Override
	public void deleteStudent(long studentId) {
		// TODO Auto-generated method stub
		studentRepository.findById(studentId).orElseThrow(()->new ResourseNotFoundException("Student ","Id",studentId));
		studentRepository.deleteById(studentId);
	}


	@Override
	public Student getStudentByEmailId(String emailID) {
		// TODO Auto-generated method stub
		 return studentRepository.findByEmailID(emailID).orElseThrow(()->new ResourseNotFoundException("Student ", "EmailID",emailID ));
	}


}
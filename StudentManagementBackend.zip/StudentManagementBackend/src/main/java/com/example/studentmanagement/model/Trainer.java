package com.example.studentmanagement.model;

import java.util.HashSet;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
@Entity
@Table(name="Trainer_Table")

public class Trainer {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator ="trainerId_gen")
	@SequenceGenerator(name = "trainerId_gen",sequenceName="trainer_sequence",initialValue = 4501,allocationSize=1)
	@Column(name = "Trainer_Id")
    private long trainerId;
 
	@Column(name="First_Name")
	@NotEmpty
	@Size(min=3 , message="firstName must contain atleast 3 characters")
	private String firstName;
	
	@Column(name="Last_Name")
	@NotEmpty
	@Size(min=1 , message="lastName must contain atleast 1 character")
	private String lastName;
	
	@Column(name="Gender")
	@NotEmpty
	@Size(min=4 , message="gender must contain atleast 4 characters")
	public String gender;
	
	@Column(name="Phone_Number")
	@NotEmpty
	@Size(min=10 ,max=10, message="phoneNumber must contain  10 digits")
	private String phoneNumber;
	
	@Column(name="Email_Id",unique=true)
	@NotEmpty
	@Email(message="Email is not valid!")
	public String emailID;
	
	@Column(name="Password")
	@NotEmpty
	@Size(min=5, message="Password length must be 5 and contain uppercase,lowercase,digits")
	@Pattern(regexp="(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{8,}")
    public String password;
	
	@JsonIgnore
	@OneToMany(mappedBy = "trainer",cascade=CascadeType.ALL)//one trainer will taught many course
	private Set<Course> course = new HashSet<Course>();

	
	public Set<Course> getCourse() {
		return course;
	}

	public void setCourse(Set<Course> course) {
		this.course = course;
	}

	public long getTrainerId() {
		return trainerId;
	}

	public void setTrainerId(long trainerId) {
		this.trainerId = trainerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	
}

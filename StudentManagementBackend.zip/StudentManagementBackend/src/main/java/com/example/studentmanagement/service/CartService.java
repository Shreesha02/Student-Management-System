package com.example.studentmanagement.service;

import java.util.List;

import com.example.studentmanagement.model.Cart;

public interface CartService {
Cart saveCart(Cart cart);

List<Cart> getCartById();

Cart getCartById(long cartId);

void deleteCart(long cartId);

Cart addCourseToCart(Cart cart,long courseId,long studentId );

List<Cart> getCartByStudentId(long studentId);

//Cart addCourseToCart(Cart cart,long courseId,String getCartBystudentEmailId );
//List<Cart> getCartByStudentEmailId(String studentEmailID);
}

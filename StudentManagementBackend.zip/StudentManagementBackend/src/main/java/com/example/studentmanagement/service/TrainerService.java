package com.example.studentmanagement.service;


import java.util.List;


import com.example.studentmanagement.model.Trainer;

public interface TrainerService {
Trainer saveTrainer(Trainer trainer);
Trainer loginTrainer(Trainer trainer);
List<Trainer> getAllTrainers();
Trainer getTrainerById(long trainerId);
//Trainer getTrainerByCourseId(Trainer trainer,long courseId);
Trainer updateTrainer(Trainer trainer, long trainerId);
Trainer getTrainerByEmail(Trainer trainer);
void deleteTrainer(long trainerId);
 

}


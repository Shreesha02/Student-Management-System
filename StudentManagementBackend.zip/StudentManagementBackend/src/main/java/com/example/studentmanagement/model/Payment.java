package com.example.studentmanagement.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Payment_Table")

public class Payment {
@Id
@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "paymentId_gen")
@SequenceGenerator(name = "paymentId_gen",sequenceName="payment_sequence",initialValue = 7001,allocationSize=1)
@Column(name="Payment_Id")
private long paymentId;

@Column(name="First_Name")
private String firstName;

@Column(name="Last_Name")
private String lastName;

@Column(name="Course_Name")
private String courseName;

@Column(name="name_on_card")
@NotEmpty
@Size(min=3 , message="name must contain atleast 3 characters")
private String nameOnCard;

@Column(name="card_number")
@NotEmpty
@Size(min=16 , max=16,message="cardNumber must contain 16 digits")
private String cardNumber;

@Column(name="exp_year")
private String expYear;

@Column(name="cvv")
@NotNull
private int cvv;

@Column(name="paid_date")
private String paidDate;

@Column(name="Total_amount")
private int totalAmount;

@JsonIgnore
@ManyToOne( cascade=CascadeType.MERGE)// many payment done by one student
@JoinColumn(name="student__id")
private Student student;

public long getPaymentId() {
	return paymentId;
}

public void setPaymentId(long paymentId) {
	this.paymentId = paymentId;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getCourseName() {
	return courseName;
}

public void setCourseName(String courseName) {
	this.courseName = courseName;
}

public String getNameOnCard() {
	return nameOnCard;
}

public void setNameOnCard(String nameOnCard) {
	this.nameOnCard = nameOnCard;
}

public String getCardNumber() {
	return cardNumber;
}

public void setCardNumber(String cardNumber) {
	this.cardNumber = cardNumber;
}

public String getExpYear() {
	return expYear;
}

public void setExpYear(String expYear) {
	this.expYear = expYear;
}

public int getCvv() {
	return cvv;
}

public void setCvv(int cvv) {
	this.cvv = cvv;
}

public String getPaidDate() {
	return paidDate;
}

public void setPaidDate(String paidDate) {
	this.paidDate = paidDate;
}

public int getTotalAmount() {
	return totalAmount;
}

public void setTotalAmount(int totalAmount) {
	this.totalAmount = totalAmount;
}

public Student getStudent() {
	return student;
}

public void setStudent(Student student) {
	this.student = student;
}


}







	


package com.example.studentmanagement.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Payment_Table")
@SequenceGenerator(name = "paymentId_gen",initialValue = 7001)
public class Payment {
@Id
@GeneratedValue(strategy = GenerationType.AUTO, generator = "paymentId_gen")
@Column(name="Payment_Id")
private long paymentId;

@Column(name="First_Name")
private String firstName;

@Column(name="Last_Name")
private String lastName;

@Column(name="Course_Name")
private String courseName;

@Column(name="Total_amount")
private int totalAmount;

@ManyToOne( cascade=CascadeType.MERGE)
@JoinColumn(name="student__id")
@JsonIgnore
private Student student;

public long getPaymentId() {
	return paymentId;
}

public void setPaymentId(long paymentId) {
	this.paymentId = paymentId;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

public String getCourseName() {
	return courseName;
}

public void setCourseName(String courseName) {
	this.courseName = courseName;
}

public int getTotalAmount() {
	return totalAmount;
}

public void setTotalAmount(int totalAmount) {
	this.totalAmount = totalAmount;
}

public Student getStudent() {
	return student;
}

public void setStudent(Student student) {
	this.student = student;
}

}







	


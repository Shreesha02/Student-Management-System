package com.example.studentmanagement.service;

import java.util.List;

import com.example.studentmanagement.model.Course;


public interface CourseService {
         Course addCouse(Course course);
         List<Course> getAllCourses();
         Course getCourseById(long courseId);
         Course updateCourse(Course course,long courseId);
     	 void deleteCourse(long courseId);
		 
}

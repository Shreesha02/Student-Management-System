package com.example.studentmanagement.service;

import java.util.List;

import com.example.studentmanagement.model.Student;

public interface StudentService {
	Student saveStudent(Student student);
	Student loginStudent(Student student);
	List<Student> getAllStudents();
	Student getStudentById(long studentd);
	Student updateStudent(Student student,long studentd);
	Student getStudentByEmail(Student student);
    void deleteStudent(long studentd);
}

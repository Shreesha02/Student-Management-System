
package com.example.studentmanagement.service;

import java.util.List;


import com.example.studentmanagement.model.Payment;


public interface PaymentService {
	Payment addPaymentByStudentId(Payment payment,long studentId);
	List<Payment> getAllPayments();
	Payment getPaymentById(long paymentId);
	Payment updatePayment(Payment payment,long paymentId);
	void deletePayment(long paymentId);
	//public List<Payment> getAllPaymentsByStudentId(long studentId);
	
	
	
}

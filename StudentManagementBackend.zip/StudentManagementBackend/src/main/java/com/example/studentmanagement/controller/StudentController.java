package com.example.studentmanagement.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.service.StudentService;

@RestController //is controller which provides different end points to access the services 
@RequestMapping("/api/student")
@CrossOrigin(origins="http://localhost:4200")
public class StudentController {
	@Autowired
	private StudentService studentService;

	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
	}

	//Register Student
		
		@PostMapping("/register")
		public ResponseEntity<Student> saveStudent(@Valid @RequestBody Student student)
		{
			
			return new ResponseEntity<Student>(studentService.saveStudent(student),HttpStatus.CREATED);
		}
	//Login Student
		@PostMapping("/login")
		public  ResponseEntity<Student> loginStudent( @RequestBody Student student)
		{
		    
			
			return new ResponseEntity<Student>(studentService.loginStudent(student),HttpStatus.OK);
			
		}
	//Update Student
		@PutMapping("{studentd}")
		public ResponseEntity<Student> updateStudent( @PathVariable("studentd") long studentd, @RequestBody Student student)
		{
			return new ResponseEntity<Student>(studentService.updateStudent(student, studentd),HttpStatus.OK);
		}
	//Get All Student
		@GetMapping
		public List<Student> getAllStudents()
		{
			return studentService.getAllStudents();
		}
		//get Student by email
		@PostMapping("/forgotpass")
		public Student getStudentByEmail(@RequestBody Student student)
		{
			return studentService.getStudentByEmail(student);
		}
		//get Student by id
		@GetMapping("{studentd}")
		public ResponseEntity<Student> getStudentById(@PathVariable("studentd") long studentd)
		{
			return new ResponseEntity<Student>(studentService.getStudentById(studentd),HttpStatus.OK);
		}
	//Delete Student	
		@DeleteMapping("{studentd}")
		public ResponseEntity<String> deleteStudent(@PathVariable("studentd") long studentd)
		{
			return new ResponseEntity<String> ("Student Record  is Deleted Successfully", HttpStatus.OK);
		}
	
}



	
	
package com.example.studentmanagement.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.studentmanagement.model.Student;

import com.example.studentmanagement.service.StudentService;

@RestController //is controller which provides different end points to access the services 
@RequestMapping("/api/student")
@CrossOrigin(origins="http://localhost:4200")
public class StudentController {
	@Autowired
	private StudentService studentService;
	
	public StudentController(StudentService studentService) {
		super();
		this.studentService = studentService;
		
	}
	//Register Student
		
		@PostMapping("/register")
		public ResponseEntity<Student> saveStudent(@Valid @RequestBody Student student)
		{
			
			return new ResponseEntity<Student>(studentService.saveStudent(student),HttpStatus.CREATED);
		}
		
	//Login Student
		@PostMapping("/login")
		public  ResponseEntity<Student> loginStudent( @RequestBody Student student)
		{
		    
			
			return new ResponseEntity<Student>(studentService.loginStudent(student),HttpStatus.OK);
			
		}
		
	//Forget Password get Student by email
		
		@PostMapping("/forgotpass")
		public Student getStudentByEmailId(@RequestBody String student)
		{
			return studentService.getStudentByEmailId(student);
		}
		
	//Update Student
		@PutMapping("{studentId}")
		public ResponseEntity<Student> updateStudent( @PathVariable("studentId") long studentId, @RequestBody Student student)
		{
			return new ResponseEntity<Student>(studentService.updateStudent(student, studentId),HttpStatus.OK);
		}
		
		
		
	//Get All Student
		@GetMapping
		public List<Student> getAllStudents()
		{
			return studentService.getAllStudents();
		}
		
		//get Student by id
		@GetMapping("{studentId}")
		public ResponseEntity<Student> getStudentById(@PathVariable("studentId") long studentId)
		{
			return new ResponseEntity<Student>(studentService.getStudentById(studentId),HttpStatus.OK);
		}
		
	//Delete Student	
		@DeleteMapping("{studentId}")
		public ResponseEntity<String> deleteStudent(@PathVariable("studentId") long studentId)
		{
			studentService.deleteStudent(studentId);
			return new ResponseEntity<String> ("Student Record  is Deleted Successfully", HttpStatus.OK);
		}
	
}



	
	
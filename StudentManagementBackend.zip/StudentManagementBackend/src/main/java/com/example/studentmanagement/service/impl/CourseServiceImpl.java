package com.example.studentmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.studentmanagement.exception.ResourseNotFoundException;
import com.example.studentmanagement.model.Course;
import com.example.studentmanagement.repository.CourseRepository;
import com.example.studentmanagement.service.CourseService;

@Service
public class CourseServiceImpl implements CourseService{
@Autowired
private CourseRepository  courseRepository;


	public CourseServiceImpl(CourseRepository courseRepository) {
	super();
	this.courseRepository = courseRepository;
}


	@Override
	public Course addCouse(Course course) {
		
		return  courseRepository.save(course);
	}


	@Override
	public List<Course> getAllCourses() {
		
		return courseRepository.findAll();
	}


	@Override
	public Course getCourseById(long courseId) {
		
		return courseRepository.findById(courseId).orElseThrow(()->new ResourseNotFoundException("Course","Id",courseId));
	}


	@Override
	public Course updateCourse(Course course, long courseId) {
		
		Course course1 = getCourseById(courseId);
		course1. setCourseName(course.getCourseName());
		course1. setCourseDuration(course.getCourseDuration());
		course1. setCourseFees(course.getCourseFees());
		return courseRepository.save(course1);
		
	}


	@Override
	public void deleteCourse(long courseId) {
		// TODO Auto-generated method stub
		System.out.println("Deleted Service");
		courseRepository.findById(courseId).orElseThrow(()-> new ResourseNotFoundException("course", "courseId", courseId));
		courseRepository.deleteById(courseId);
	}


	
	

	

}

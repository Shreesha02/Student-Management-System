package com.example.studentmanagement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.studentmanagement.model.Payment;
import com.example.studentmanagement.service.PaymentService;

@CrossOrigin(origins="http://localhost:4200")
@RestController //is controller which provides different end points to access the services 
@RequestMapping("/api/payment")
public class PaymentController {
	@Autowired
	PaymentService paymentService;
	
	public PaymentController(PaymentService paymentService) {
		super();
		this.paymentService = paymentService;
	}
	//making payment
	@PostMapping("{studentId}")
	public ResponseEntity<Payment> addPaymentBySudentId(@PathVariable("studentId") long studentId, @RequestBody Payment payment)
	{
		return new ResponseEntity<Payment>(paymentService.addPaymentByStudentId(payment,studentId),HttpStatus.CREATED);
	}
	
	//getting list of payments
	@GetMapping  
	public List<Payment> getAlPayments()
	{
		return paymentService.getAllPayments();
	}
	
	 @PutMapping("{paymentId}")
	 public ResponseEntity<Payment>updatePaymentById(@PathVariable("paymentId") long paymentId,@RequestBody Payment payment ) 
	 { 
		 return new ResponseEntity<Payment>(paymentService.updatePayment(payment, paymentId),HttpStatus.OK);
	 }

	//to get payment by payment id(for receipt)
    @GetMapping("{paymentId}")
	public ResponseEntity<Payment> getPaymentById(@PathVariable("paymentId") long paymentId)
	{
		return new ResponseEntity<Payment>(paymentService.getPaymentById(paymentId),HttpStatus.OK);
	}
		
		
	// to delete payment
	@DeleteMapping("{paymentId}")
	public ResponseEntity<String> deletePayment(@PathVariable("paymentId") long paymentId)
	{
		paymentService.deletePayment(paymentId);
		return new ResponseEntity<String> ("Payment Record  is Deleted Successfully", HttpStatus.OK);
	}
	 
}

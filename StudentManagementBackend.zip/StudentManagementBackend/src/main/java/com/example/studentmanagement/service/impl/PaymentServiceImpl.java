
package com.example.studentmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.studentmanagement.exception.ResourseNotFoundException;
import com.example.studentmanagement.model.Payment;
import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.PaymentRepository;
import com.example.studentmanagement.service.PaymentService;
import com.example.studentmanagement.service.StudentService;

@Service
public class PaymentServiceImpl implements PaymentService{
@Autowired 
PaymentRepository  paymentRepository;
StudentService studentService;



public PaymentServiceImpl(PaymentRepository paymentRepository, StudentService studentService) {
	super();
	this.paymentRepository = paymentRepository;
	this.studentService = studentService;
}

@Override
public Payment addPaymentByStudentId(Payment payment,long studentId) {
	
	Student student =studentService.getStudentById(studentId);
	payment.setStudent(student);
	return paymentRepository.save(payment);
}

@Override
public List<Payment> getAllPayments() {
	// TODO Auto-generated method stub
	return paymentRepository.findAll();
}

/*
 * @Override public List<Payment> getAllPaymentsByStudentId(long studentId) { //
 * TODO Auto-generated method stub return
 * paymentRepository.findByStudentId(studentId); }
 */
	
@Override
public Payment getPaymentById(long paymentId) {
	// TODO Auto-generated method stub
	return paymentRepository.findById(paymentId).orElseThrow(()->new ResourseNotFoundException("Payment","Id",paymentId));
}

@Override
public void deletePayment(long paymentId) {
	// TODO Auto-generated method stub
	paymentRepository.findById(paymentId).orElseThrow(()-> new ResourseNotFoundException("payment", "paymentId", paymentId));
	paymentRepository.deleteById(paymentId);
}

@Override
public Payment updatePayment(Payment payment, long paymentId) {
	// TODO Auto-generated method stub
	Payment payment1 = getPaymentById(paymentId);
	payment1.setFirstName(payment.getFirstName());
	payment1.setLastName(payment.getLastName());
	payment1.setCourseName(payment.getCourseName());
	payment1.setTotalAmount(payment.getTotalAmount());
	return paymentRepository.save(payment1);
}




}

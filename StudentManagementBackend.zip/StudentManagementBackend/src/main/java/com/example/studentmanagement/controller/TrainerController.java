package com.example.studentmanagement.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.studentmanagement.model.Trainer;

import com.example.studentmanagement.service.TrainerService;
@CrossOrigin(origins="http://localhost:4200")
@RestController //is controller which provides different end points to access the services 
@RequestMapping("/api/trainer")

public class TrainerController {
	@Autowired
	private TrainerService trainerService;
	
	
	public TrainerController(TrainerService trainerService) {
		super();
		this.trainerService = trainerService;
		
	}

//Register Trainer
	@PostMapping("/register")
	public ResponseEntity<Trainer> saveTrainer( @RequestBody Trainer trainer)
	{
	  return new ResponseEntity<Trainer>(trainerService.saveTrainer(trainer),HttpStatus.CREATED);
	}
	 
// Login Trainer
	@PostMapping("/login")
	public ResponseEntity<Trainer> loginTrainer(@Valid @RequestBody Trainer trainer)
	{
	   return new ResponseEntity<Trainer>(trainerService.loginTrainer(trainer),HttpStatus.CREATED);
	}
	
//Forget Password get trainer by email
	@PostMapping("/forgotpass")
	public Trainer getTrainerByEmail(@RequestBody Trainer trainer)
	{
	   return trainerService.getTrainerByEmail(trainer);
	}
	
// Update Trainer
	@PutMapping("{trainerId}")
	public ResponseEntity<Trainer> updateTrainer(@PathVariable("trainerId") long trainerId,@RequestBody Trainer trainer) 
	{ 
		 return new ResponseEntity<Trainer>(trainerService.updateTrainer(trainer,trainerId),HttpStatus.OK);
	}
	
	
	
	
//Get All Trainers List
	@GetMapping
	public List<Trainer> getAllTrainers()
	{
	  return trainerService.getAllTrainers();
	}
	
//get trainer by id
	@GetMapping("{id}")
	public ResponseEntity<Trainer> getTrainerById(@PathVariable("trainerId") long trainerId)
	{
		return new ResponseEntity<Trainer>(trainerService.getTrainerById(trainerId),HttpStatus.OK);
	}
	
//Delete Trainer	
	@DeleteMapping("{trainerId}")
	public ResponseEntity<String> deleteTrainer(@PathVariable("trainerId") long trainerId)
	{
	   trainerService.deleteTrainer(trainerId);
	   return new ResponseEntity<String> ("Trainer Record  is Deleted Successfully", HttpStatus.OK);
	}
		
	
}

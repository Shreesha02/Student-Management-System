package com.example.studentmanagement.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="Cart_Table")
public class Cart {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator ="cartId_gen")
	@SequenceGenerator(name = "cartId_gen",sequenceName="cart_sequence" ,initialValue=101,allocationSize=1 )
	@Column(name = "Cart_Id")
    private long cartId;
	
	@Column(name="Course_Name")
	private String courseName;
	
	@ManyToOne( cascade=CascadeType.MERGE)
	@JoinColumn(name="courseId")
	@JsonIgnore
	@OnDelete(action=OnDeleteAction.CASCADE)
	private Course course;
	
	
	
	@ManyToOne( cascade=CascadeType.MERGE)
	@JoinColumn(name="studentId")
	@JsonIgnore
	@OnDelete(action=OnDeleteAction.CASCADE)
	private Student student;

	public long getCartId() {
		return cartId;
	}

	public void setCartId(long cartId) {
		this.cartId = cartId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	
	
	}

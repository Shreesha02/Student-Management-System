package com.example.studentmanagement;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.studentmanagement.model.Trainer;
import com.example.studentmanagement.repository.TrainerRepository;


@SpringBootTest
class TrainerTestCase {
	
	@Autowired
	TrainerRepository trainerRespository;

	@Test
	public void testTrainerLogin() {
		/*
		 * Trainer trainer=new Trainer(); trainer.setEmailID("vimal@gmail.com");
		 * trainer.setPassword("Vimal@1992");
		 */
		assertNotNull(trainerRespository.findById(4501L));
	}
	
	@Test
	public void testReadAll() {
		List<Trainer> list =trainerRespository.findAll();
		assertThat(list).size().isGreaterThan(0);
		}

}

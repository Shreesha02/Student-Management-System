package com.example.studentmanagement;


import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.repository.StudentRepository;

@SpringBootTest
public class StudentTestCase {
@Autowired
StudentRepository studentRespository;
	
	@Test
	public void testCreate()
	{
	/*Student s = new Student();
	s.setFirstName("Maya");
	s.setLastName("Kiran");
	s.setGender("Female");
	s.setPhoneNumber("9874569874");
	s.setAddress("4th Floor Hornby Building, Fort");
	s.setDistrict("Mumbai");
	s.setPinCode("400001");
	s.setState("Maharashtra");
	s.setCountry("India");
	s.setEmailID("maya@gmail.com");
	s.setPassword("Maya@2002");
	studentRespository.save(s);*/
	assertNotNull(studentRespository.findById(20203L).get());
	}
	
	@Test
	public void testReadAll() {
		List<Student> list =studentRespository.findAll();
		assertThat(list).size().isGreaterThan(0);
		}

	
}

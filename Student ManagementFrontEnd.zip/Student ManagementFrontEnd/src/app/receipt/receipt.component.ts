import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';

@Component({
  selector: 'app-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.css']
})
export class ReceiptComponent {
  paymentId:number=0;
  studentId:number=0;
  payment = new Payment(0,"","","","","",0,"","",0);
    constructor(private activatedRoute:ActivatedRoute,private route:Router,private paymentService:PaymentService) { }
  
    ngOnInit(): void {
  this.paymentId=this.activatedRoute.snapshot.params["paymentId"]
  this.studentId=this.activatedRoute.snapshot.params["studentId"]
  
    this.getPaymentDetails();
    }
  getPaymentDetails()
  {
    this.paymentService.getPaymentDetails(this.paymentId).subscribe(
      data=>{console.log(data),
      this.payment=data},
      error=>console.log(error)
    )
  }
  home()
  {
    this.route.navigate(['/studenthome',this.studentId])
  }
  logOut()
  {
    this.route.navigate(['/welcomepage'])
  }
  
}

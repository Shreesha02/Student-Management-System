import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-profile',
  templateUrl: './student-profile.component.html',
  styleUrls: ['./student-profile.component.css']
})
export class StudentProfileComponent implements OnInit{
  student = new Student(0,"","","","","","","","","","","");
  message=""
  studentId:number=0;
  constructor(private studentService:StudentService,private activatedRoute:ActivatedRoute,private router:Router) { }

    ngOnInit() : void{
      this.getStudentDetatis();
    }
    getStudentDetatis()
    {
      this.studentId=this.activatedRoute.snapshot.params["studentId"]
        this.studentService.getStudentById(this.studentId).subscribe
        (data=>{this.student=data,console.log(data)})
          }
          
   saveProfile(studentId:number,student:Student)
    {
      this.studentService.saveProfile(studentId,student).subscribe
      (data=>{console.log(data),
        alert("Profile Updated Successfully");},
          error=>console.log(error)
      )
    }
    
        backToStudentHome(studentId:number)
        {
        this.router.navigate(['/studenthome',studentId])
        }
        logOut()
        {
          this.router.navigate(['/welcomepage'])
        }
        
        studentProfile()
        {
          this.router.navigate(['/profile',this.studentId])
        }
        genders=["Male","Female","Other"]
        contactUs()
        {
          this.router.navigate(['/contactus'])
        }

}

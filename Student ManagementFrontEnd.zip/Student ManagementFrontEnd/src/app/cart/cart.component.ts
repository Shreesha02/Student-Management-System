import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Cart } from '../cart';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit{
 cart = new Cart(0,"",0,0);
 cartList:any;
   courseId:number=0;
   studentId:number=0;
   //studentEmailId:string ="";
   constructor(private cartService: CartService, private activatedroute:ActivatedRoute,private router:Router) {}
ngOnInit(): void {
  this.courseId = this.activatedroute.snapshot.params["courseId"];
  this.studentId = this.activatedroute.snapshot.params["studentId"];
  }
 
public addCourseToCart() {
   console.log("buttonclick");
   console.log(this.cart);
   let res=this.cartService.addCart(this.cart,this.courseId,this.studentId).subscribe((data:any)=> {console.log ("added")});
   console.log(res);

   this.router.navigate(['/cartdetails',this.studentId]);
}


  logOut()
 {
  this.router.navigate(['/welcomepage'])
 }
 back()
 {
  this.router.navigate(['/viewcourseList'])
 }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Course } from './course';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  
  constructor(private http:HttpClient) { }
  
public createCourse(course:Course):Observable<Object>
{
    console.log("service");
    console.log(Course);
    return this.http.post<any>("http://localhost:8089/api/course",course,{responseType:'text' as 'json'});
}
  
public getCourseList():Observable<any>
{ 
  console.log("Get Course in Service");
  return  this.http.get<any>("http://localhost:8089/api/course");
}

public deleteCourse(courseId:number)
{
  console.log("delete course in service");
  return this.http.delete<any>("http://localhost:8089/api/course/"+courseId,{responseType:'text' as 'json'});
}

public getCourseById(courseId:number):Observable<Course>
{
  
  return this.http.get<Course>("http://localhost:8089/api/course/"+courseId);
}

public updateCourse(courseId:number,course:Course):Observable<any>
{
  console.log("update course");
  return this.http.put("http://localhost:8089/api/course/"+courseId,course,{responseType:'text' as 'json'});
}

/*public getAllCourses():Observable<any>
{ 
  return  this.http.get<any>("http://localhost:8089/api/course");
}*/

}
  

  





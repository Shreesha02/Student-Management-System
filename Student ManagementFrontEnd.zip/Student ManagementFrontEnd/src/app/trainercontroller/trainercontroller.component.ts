import { Component, OnInit } from '@angular/core';
import {  Router } from '@angular/router';
import { Trainer } from '../trainer';
import { TrainerService } from '../trainer.service';

@Component({
  selector: 'app-trainercontroller',
  templateUrl: './trainercontroller.component.html',
  styleUrls: ['./trainercontroller.component.css']
})
export class TrainercontrollerComponent implements OnInit{
   trainer = new Trainer(0,"","","","","","");
   message=""
   constructor(private trainerService:TrainerService,private router:Router){}
   ngOnInit(): void {
    console.log("inside OnInit")
    this.trainer.gender="Male"
  }
   registerTrainer(){
    console.log("buttonclick");
    console.log(this.trainer);
    this.trainerService.registerTrainer(this.trainer).subscribe(
      data =>{console.log("Login Succes"),
    this.router.navigate(['/trainerlogin'])},
      error =>{console.log("Login Failed"),
    this.message="login failed. try again"})
    }


  genders=["Male","Female","Other"]
  back()
      {
        this.router.navigate(['/welcomepage'])
      }
}

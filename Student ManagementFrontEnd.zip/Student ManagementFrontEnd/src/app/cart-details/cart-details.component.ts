import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Cart } from '../cart';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-cart-details',
  templateUrl: './cart-details.component.html',
  styleUrls: ['./cart-details.component.css']
})
export class CartDetailsComponent implements OnInit{
  cart = new Cart(0,"",0,0);
  cartList:any;
  message:any;
  studentId:number=0;
   //studentEmailId:string ="";
    constructor(private cartService: CartService, private activatedroute:ActivatedRoute,private router:Router) {}

    ngOnInit(): void {
      this.studentId=this.activatedroute.snapshot.params["studentId"];
        
      console.log("inside OnInit")
      this.getCartListByStudentId();
  
    }
    private getCartListByStudentId() {
      let res = this.cartService.getAllCartByStudentId(this.studentId);
      res.subscribe((data:any) =>{console.log(data), this.cartList = data},
      error=>{console.log(error)}
      );
    }

    public getCartList()
   {
      this.cartService.getCartList().subscribe(data => {this.cartList = data;});
   } 

    removeFromCart(cartId:number) 
    {
      console.log("deleteCourse");
      this.cartService.delete(cartId).subscribe
      ((data:any)=>{console.log("deleted Seccessfully"),
      this.cartList();},
      error=>{console.log ("delete failed"),
      this.message = "Unable to delete, Please Try Again"}
      )}
      addPayment(studentId:number)
      {
       this.router.navigate(['/paymentcontroller',studentId])
      }
      addMoreCourse(){
        this.router.navigate(['/viewcourseList',this.studentId]);
      }
      back()
      {
        this.router.navigate(['/cartdetails',this.studentId])
      }
      logOut()
      {
        this.router.navigate(['/welcomepage'])
      }

  
}

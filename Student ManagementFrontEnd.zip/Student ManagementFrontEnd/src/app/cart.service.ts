import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cart } from './cart';

@Injectable({
  providedIn: 'root'
})
export class CartService {
 

  constructor(private http:HttpClient) { }
  

public addCart(cart:Cart, courseId:number,studentId:number): Observable<any>{
  console.log("service");
  console.log(cart);
   return this.http.post<any>("http://localhost:8089/api/cart/add/"+courseId+"/"+studentId,cart,{responseType:'Text' as 'json'});
 }
 
 public getAllCartByStudentId(studentId:number){
  console.log("inside Cart Service");
  return this.http.get("http://localhost:8089/api/cart/student/"+studentId);
 }

 public getCartList(){
  return this.http.get("http://localhost:8089/api/cart");
 }

 public delete(cartId:number) {
  console.log("inside Cart Service");
  return this.http.delete("http://localhost:8089/api/cart/"+cartId,{responseType:'Text' as 'json'} );
 }

}

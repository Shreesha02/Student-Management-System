import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Trainer } from './trainer';

@Injectable({
  providedIn: 'root'
})
export class TrainerService {

constructor(private http:HttpClient) { }

public registerTrainer(trainer:Trainer):Observable<any>
{
    console.log("service");
    console.log(Trainer);
    return  this.http.post<any>("http://localhost:8089/api/trainer/register",trainer,{responseType:'text' as 'json'});
}
public getAllTrainers()
{
  return  this.http.get<any>("http://localhost:8089/api/trainer");
}

public loginTrainer(trainer:Trainer):Observable<any>
{
  console.log("Trainer Service");
  return this.http.post<any>("http://localhost:8089/api/trainer/login",trainer);
  }
}

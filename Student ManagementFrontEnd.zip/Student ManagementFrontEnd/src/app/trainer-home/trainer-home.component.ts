import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-trainer-home',
  templateUrl: './trainer-home.component.html',
  styleUrls: ['./trainer-home.component.css']
})
export class TrainerHomeComponent implements OnInit{
 
  constructor(private activatedroute:ActivatedRoute,private router:Router) { }
ngOnInit(): void {
  
}
  
   logOut()
   {
       this.router.navigate(['/welcomepage'])
   }
   
}

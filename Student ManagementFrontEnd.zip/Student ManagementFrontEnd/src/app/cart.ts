export class Cart{
    constructor(
        public cartId:number,
        public courseName:string,
        public courseId:number,
        public studentId:number

       // public emailID:string
        
    ){

    }
}
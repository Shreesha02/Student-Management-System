import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Student } from './student';
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  
constructor(private http:HttpClient) { }

public registerStudent(student:Student):Observable<any>
{
   console.log("service");
   console.log(Student);
   return  this.http.post<any>("http://localhost:8089/api/student/register",student,{responseType:'text' as 'json'});
}

public loginStudent(student:Student):Observable<any>
{
   return this.http.post<any>("http://localhost:8089/api/student/login",student);
   //{responseType:'text' as 'json'}
}

public getStudentById(studentId:number):Observable<Student>
{
   console.log("get service");
   return  this.http.get<Student>("http://localhost:8089/api/student"+studentId);
}

public saveProfile(studentId:number,student:Student):Observable<any>
{
   return this.http.put<any>("http://localhost:8089/api/student"+studentId,student);
}

public getAllStudents()
{
  return  this.http.get<any>("http://localhost:8089/api/student");
}

public getStudentByEmailId(student:Student):Observable<any>
{
   return this.http.post<any>("http://localhost:8089/api/student/forgotpass",student,{responseType:'text' as 'json'});
}

}

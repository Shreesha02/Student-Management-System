export class Trainer{
constructor(
    public trainerId:number,
    public firstName:string,
	 public lastName:string,
	 public gender:string,
	 public phoneNumber:string,
     public emailID:string,
	 public password:string
){}
}
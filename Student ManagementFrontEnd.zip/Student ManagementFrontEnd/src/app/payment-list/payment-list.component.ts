import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';

@Component({
  selector: 'app-payment-list',
  templateUrl: './payment-list.component.html',
  styleUrls: ['./payment-list.component.css']
})
export class PaymentListComponent implements OnInit{
  payment = new Payment(0,"","","","","",0,"","",0);
  paymentList:any;
  studentId:number=0;
  constructor(private paymentService:PaymentService,private activatedroute:ActivatedRoute,private router:Router){}
  ngOnInit(): void {
    this.getPaymentList();
    this.studentId=this.activatedroute.snapshot.params["studentId"];
  }
  
   public getPaymentList()
  {
    this.paymentService.getPaymentList().subscribe(data => {this.paymentList = data; });
  }
    
back()
{
  this.router.navigate(['/studenthome',this.studentId])
}
logOut()
  {
    this.router.navigate(['/welcomepage'])
  }
}

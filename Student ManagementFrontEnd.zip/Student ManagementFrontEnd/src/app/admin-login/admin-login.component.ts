import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { Admin } from '../admin';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit{
  admin=new Admin(0,"","","","");
  message=""
    constructor(private adminService:AdminService,private router:Router) { }
  
    ngOnInit(): void {
    }
  adminLogin()
  {
  console.log("Admin Login Controller");
  this.adminService.adminLogin(this.admin).subscribe(data=>{console.log("login Success"),
  this.router.navigate(['/adminhome'])},
  error =>{console.log("Login Failed"),console.log(error),

  this.message="login failed.enter valid email and password"}
  )
  }
  back()
  {
    this.router.navigate(['/welcomepage'])
  }
}

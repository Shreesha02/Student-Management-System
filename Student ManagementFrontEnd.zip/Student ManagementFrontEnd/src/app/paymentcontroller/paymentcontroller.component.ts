import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Course } from '../course';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';
import { Student } from '../student';

@Component({
  selector: 'app-paymentcontroller',
  templateUrl: './paymentcontroller.component.html',
  styleUrls: ['./paymentcontroller.component.css']
})
export class PaymentcontrollerComponent implements OnInit{
paymentId:number=0;
payment = new Payment(0,"","","","","",0,"","",0);
student = new Student(0,"","","","","","","","","","","");
studentId:number=0;
course = new Course(0,"",0,"");
 courseId:number=0;
constructor(private paymentService:PaymentService,private activatedRoute:ActivatedRoute,private router:Router){}
ngOnInit(): void {
  this.studentId = this.activatedRoute.snapshot.params["studentId"];
  this.courseId = this.activatedRoute.snapshot.params["courseId"];
}


  getStudentDetails()
  {
    this.paymentService.getStudentDetails(this.studentId).subscribe(
      data=>{console.log(data),
      this.student=data},
      error=>console.log(error)
    )
  }
 /*addPayment(_studentId: any){
  this.paymentService.addPayment(this.payment,this.studentId).subscribe(
    (data:any)=>{this.paymentId=data.paymentId ,this.studentId=data.studentId
      console.log("Add Payment SuccessFully")},
    (error:any)=>{console.log("payment failed")}
    )
}*/

public addPayment() {
  console.log("buttonclick");
  this.paymentService.addPayment(this.payment,this.studentId).subscribe(data=>{console.log("payement success"+data),
  this.paymentId=data.payementId,
  alert("Payement Successfull"),
  this.router.navigate(['/paymentreciept',this.studentId,this.paymentId])},
  error=>console.log(error));
 }

 

studenthome()
{
  this.router.navigate(['/studenthome',this.studentId])
} 
/*studentProfile()
{
  this.router.navigate(['/profile',this.studentId])
}*/
back()
{
  this.router.navigate(['/viewcourseList'])
}
logOut()
{
  this.router.navigate(['/welcomepage'])
}
contactUs()
{
  this.router.navigate(['/contact'])
}
}





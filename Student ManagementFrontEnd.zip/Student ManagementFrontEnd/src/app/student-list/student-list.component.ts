import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit{
  student = new Student(0,"","","","","","","","","","","");
  studentList:any;
  constructor(private studentservice:StudentService,private router:Router){}
  ngOnInit(): void {
    let res = this.studentservice.getAllStudents();
    res.subscribe((data:any) => this.studentList=data);
  }
  
back()
 {
  this.router.navigate(['/adminhome'])
 }
logOut()
  {
    this.router.navigate(['/welcomepage'])
  }
}

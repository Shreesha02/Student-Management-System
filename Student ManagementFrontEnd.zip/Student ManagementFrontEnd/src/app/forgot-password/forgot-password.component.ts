import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit{
  student = new Student(0,"","","","","","","","","","","");
  status!: boolean;
studentId:number=0;
message=""
  constructor(private studentService:StudentService,private router:Router){}

  ngOnInit(): void {
    
  }
submitEmail()
{
  this.studentService.getStudentByEmailId(this.student).subscribe(
    data=>{console.log(data),
      alert("Success......enter new password")
    this.studentId=data.studentId,
this.student=data
this.status=true
},

    error=>{console.log(error),
      this.message="email does not exist! enter correct email."
      this.status=false}
  )
}
submitPass()
{
  this.studentService.saveProfile(this.studentId,this.student).subscribe(
    data=>{console.log(data),
    alert("Password Updated Successfully");
  this.router.navigate(['/studentlogin'])},
    error=>console.log(error)
  )
}
}

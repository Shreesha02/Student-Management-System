export class Payment{
    constructor(
     public paymentId:number,
     public firstName:string,
	 public lastName:string,
     public courseName:string,
     public nameOnCard:string,
     public cardNumber:String,
     public cvv:number,
     public expYear:string,
     public paidDate:string,
     public totalAmount:number
    ){}
}
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Course } from '../course';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrls: ['./update-course.component.css']
})
export class UpdateCourseComponent implements OnInit{
course = new Course(0,"",0,"");

  courseId: number=0;
  constructor(private courseService:CourseService,private router:Router,private activatedroute:ActivatedRoute) { }

  ngOnInit(): void {
    console.log("inside OnInit");
    this.courseId=this.activatedroute.snapshot.params["courseId"];
    this.courseService.getCourseById(this.courseId).subscribe(
     data=>{this.course=data,console.log(data)},
      error=>console.log(error)
   ) 
  }
  updateCourse()
  {
    this.courseService.updateCourse(this.courseId,this.course).subscribe(
      data=>{console.log(data),
      alert("updated successfully")
      this.router.navigate(['/courseList'])},
      error=>console.log(error)
    )
  }
  logOut()
  {
    this.router.navigate(['/welcomepage'])
  }
  
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-register',
  templateUrl: './student-register.component.html',
  styleUrls: ['./student-register.component.css']
})
export class StudentRegisterComponent implements OnInit {
  student = new Student(0,"","","","","","","","","","","");
  studentlist:any;
  studentId:number=0;
  message=""
  constructor(private studentService:StudentService,private router:Router){}
  ngOnInit(): void {
    console.log("inside OnInit")
    let res = this.studentService.getAllStudents();
   res.subscribe((data:any) => this.studentlist = data );
   }


 registerStudent(){
  this.studentService.registerStudent(this.student).subscribe(
    data =>{console.log("Login Succes"),
  this.router.navigate(['/studentlogin'])},
    error =>{console.log("Login Failed"),
  this.message="login failed. try again"})
  }


genders=["Male","Female","Other"]
back()
    {
      this.router.navigate(['/welcomepage'])
    }
}

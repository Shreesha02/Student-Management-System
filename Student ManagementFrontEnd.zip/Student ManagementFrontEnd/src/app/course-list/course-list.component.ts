import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../course';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrls: ['./course-list.component.css']
})
export class CourseListComponent implements OnInit{
 course = new Course(0,"",0,"");
 courseId:number=0;
 courseList:any;
  constructor(private courseService:CourseService,private route:Router) { }

  ngOnInit(): void {
    this.getCourseList();
  }
  
private getCourseList()
{
   this.courseService.getCourseList().subscribe(data => {this.courseList = data;});
}
  
 updateCourse(courseId:number)
 {
    this.route.navigate(['/updateCourse',courseId]);
 }

 deleteCourse(courseId:number)
 {
  console.log("delete course in component class");
   this.courseService.deleteCourse(courseId).subscribe(
    (data:any)=>{console.log("deleted sucessfully"),
    this.getCourseList();},
    error=>console.log("delete failed")
  )
}

  /*home()
  {
    this.route.navigate(['/adminhome'])
  }
  contactUs()
  {
    this.route.navigate(['/contactus'])
  }*/
 
  logOut()
 {
  this.route.navigate(['/welcomepage'])
 }
 back()
 {
  this.route.navigate(['/createCourse'])
 }
}



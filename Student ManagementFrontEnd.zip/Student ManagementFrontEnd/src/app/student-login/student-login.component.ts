import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-login',
  templateUrl: './student-login.component.html',
  styleUrls: ['./student-login.component.css']
})
export class StudentLoginComponent implements OnInit{
student = new Student(0,"","","","","","","","","","","");
message=""
  studentId: number=0;
  constructor(private studentService:StudentService,private router:Router) { }
  ngOnInit() : void{
    
  }
studentLogin()
{
  console.log("Student Login Controller");
  this.studentService.loginStudent(this.student).subscribe((data:any)=>{this.studentId=data.studentId, console.log("Login Success"),
  this.router.navigate(['/studenthome',this.studentId])},
  error =>{console.log("Login failed"),console.log(error),
  this.message="login failed. Enter valid email and password"}
)
}

back()
{
  this.router.navigate(['/welcomepage'])
}


}

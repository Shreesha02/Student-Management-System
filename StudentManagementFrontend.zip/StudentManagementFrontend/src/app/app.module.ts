import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { HttpClient, HttpClientModule } from '@angular/common/http';



import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AdminService } from './admin.service';
import { StudentRegisterComponent } from './student-register/student-register.component';
import { StudentLoginComponent } from './student-login/student-login.component';
import { AdminRegisterComponent } from './admin-register/admin-register.component';
import { CourseListComponent } from './course-list/course-list.component';
import { CreateCourseComponent } from './create-course/create-course.component';
import { UpdateCourseComponent } from './update-course/update-course.component';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentHomeComponent } from './student-home/student-home.component';
import { TrainercontrollerComponent } from './trainercontroller/trainercontroller.component';
import { TrainerLoginComponent } from './trainer-login/trainer-login.component';
import { TrainerListComponent } from './trainer-list/trainer-list.component';
import { PaymentcontrollerComponent } from './paymentcontroller/paymentcontroller.component';
import { PaymentListComponent } from './payment-list/payment-list.component';
import { ViewCourseListComponent } from './view-course-list/view-course-list.component';
import { StudentProfileComponent } from './student-profile/student-profile.component';



@NgModule({
  declarations: [
    AppComponent,
    
    AdminHomeComponent,
    AdminLoginComponent,
    WelcomeComponent,
    AboutUsComponent,
    ContactUsComponent,
    StudentRegisterComponent,
    StudentLoginComponent,
    AdminRegisterComponent,
    CourseListComponent,
    CreateCourseComponent,
    UpdateCourseComponent,
    StudentListComponent,
    StudentHomeComponent,
    TrainercontrollerComponent,
    TrainerLoginComponent,
    TrainerListComponent,
    PaymentcontrollerComponent,
    PaymentListComponent,
    ViewCourseListComponent,
    StudentProfileComponent
   
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

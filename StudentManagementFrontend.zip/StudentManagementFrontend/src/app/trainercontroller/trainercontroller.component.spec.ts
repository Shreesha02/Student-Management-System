import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TrainercontrollerComponent } from './trainercontroller.component';

describe('TrainercontrollerComponent', () => {
  let component: TrainercontrollerComponent;
  let fixture: ComponentFixture<TrainercontrollerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TrainercontrollerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TrainercontrollerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component } from '@angular/core';
import {  Router } from '@angular/router';
import { Trainer } from '../trainer';
import { TrainerService } from '../trainer.service';

@Component({
  selector: 'app-trainercontroller',
  templateUrl: './trainercontroller.component.html',
  styleUrls: ['./trainercontroller.component.css']
})
export class TrainercontrollerComponent {
   trainer = new Trainer(0,"","","","","","");
   constructor(private trainerService:TrainerService,private router:Router){}
   public registerTrainer(){
    console.log("buttonclick");
    console.log(this.trainer);
    let res =this.trainerService.registerTrainer(this.trainer);
    console.log(res);
  }
  back()
      {
        this.router.navigate(['/welcomepage'])
      }
}

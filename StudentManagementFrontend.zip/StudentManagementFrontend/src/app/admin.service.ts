import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './admin';
@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http:HttpClient) { }
  
  public adminLogin(admin:Admin):Observable<any>
  {
    console.log("admin login service");
    return this.http.post<any>("http://localhost:8089/api/admin/login",admin,{responseType:'text' as 'json'});
  }

 public registeradmin(admin:Admin):Observable<any>{
    console.log("service");
    console.log(admin);
    return  this.http.post<any>("http://localhost:8089/api/admin/register",admin,{responseType:'text' as 'json'});
  }
  
}

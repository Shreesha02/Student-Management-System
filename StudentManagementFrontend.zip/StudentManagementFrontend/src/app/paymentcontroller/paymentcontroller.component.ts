import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';
import { Student } from '../student';

@Component({
  selector: 'app-paymentcontroller',
  templateUrl: './paymentcontroller.component.html',
  styleUrls: ['./paymentcontroller.component.css']
})
export class PaymentcontrollerComponent {
paymentId=0;
payment = new Payment(0,"","","",0);
student = new Student(0,"","","","","","","","","","","");
studentId=0;

constructor(private paymentService:PaymentService,private router:Router){}


  getStudentDetails()
  {
    this.paymentService.getStudentDetails(this.studentId).subscribe(
      data=>{console.log(data),
      this.student=data},
      error=>console.log(error)
    )
  }
 addPayment(_studentId: any){
  
   this.paymentService.addPayment(this.payment,this.studentId).subscribe(
    (data:any)=>{console.log("payment success"),
    this.paymentId=data.paymentId},
    (error:any)=>{console.log("payment failed")}
    )
}
studentProfile()
{
  this.router.navigate(['/profile',this.studentId])
}
back()
{
  this.router.navigate(['/adminhome'])
}
logOut()
{
  this.router.navigate(['/welcomepage'])
}
contactUs()
{
      this.router.navigate(['/contact'])
}
}





import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentcontrollerComponent } from './paymentcontroller.component';

describe('PaymentcontrollerComponent', () => {
  let component: PaymentcontrollerComponent;
  let fixture: ComponentFixture<PaymentcontrollerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentcontrollerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentcontrollerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-register',
  templateUrl: './student-register.component.html',
  styleUrls: ['./student-register.component.css']
})
export class StudentRegisterComponent  {
  student = new Student(0,"","","","","","","","","","","");
  
  constructor(private studentService:StudentService,private router:Router){}
  
public registerStudent(){
  console.log("buttonclick");
  console.log(this.student);
  let res =this.studentService.registerStudent(this.student);
  console.log(res);
}
back()
    {
      this.router.navigate(['/welcomepage'])
    }
}

export class Student{
    constructor(
    public studentId:number,
    public firstName:string,
	public lastName:string,
	public gender:string,
	public phoneNumber:string,
	public address:string,
    public district:string,
	public pinCode:string,
	public state:string,
	public country:string,
	public emailID:string,
	public password:string
    ){
        
    }
}
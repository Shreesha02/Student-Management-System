import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Payment } from '../payment';
import { PaymentService } from '../payment.service';

@Component({
  selector: 'app-payment-list',
  templateUrl: './payment-list.component.html',
  styleUrls: ['./payment-list.component.css']
})
export class PaymentListComponent implements OnInit{
  payment = new Payment(0,"","","",0);
  paymentList:any;
  constructor(private paymentService:PaymentService,private router:Router){}
  ngOnInit(): void {
    this.getPaymentList();
  }
  
   private getPaymentList()
  {
    this.paymentService.getPaymentList().subscribe(data => {
      this.paymentList = data;
    });}
  
     back()
{
  this.router.navigate(['/adminhome'])
}
logOut()
  {
    this.router.navigate(['/welcomepage'])
  }
}

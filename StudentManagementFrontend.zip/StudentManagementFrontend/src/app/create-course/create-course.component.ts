import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Course } from '../course';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-create-course',
  templateUrl: './create-course.component.html',
  styleUrls: ['./create-course.component.css']
})
export class CreateCourseComponent {
  course = new Course(0,"","","");
 
  constructor(private courseService:CourseService,private router:Router) { }

  ngOnInit(): void {
  }
  saveCourse(){
    this.courseService.createCourse(this.course).subscribe( data =>{
      console.log(data);
      this.goToCourseList();
    },
    error => console.log(error));
  }
  

  goToCourseList(){
    this.router.navigate(['/courseList']);
  }
  
  onSubmit(){
    console.log(this.course);
    this.saveCourse();
  }
 
  logOut()
{
  this.router.navigate(['/welcomepage'])
}

}

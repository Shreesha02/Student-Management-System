import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Trainer } from '../trainer';
import { TrainerService } from '../trainer.service';

@Component({
  selector: 'app-trainer-list',
  templateUrl: './trainer-list.component.html',
  styleUrls: ['./trainer-list.component.css']
})
export class TrainerListComponent {
  trainer = new Trainer(0,"","","","","","");
  trainerList:any;
  constructor(private trainerService:TrainerService,private router:Router){}
  ngOnInit(): void {
    let res = this.trainerService.getAllTrainers();
    res.subscribe((data:any) => this.trainerList=data);
  }
  back()
{
  this.router.navigate(['/adminhome'])
}
logOut()
  {
    this.router.navigate(['/welcomepage'])
  }
}

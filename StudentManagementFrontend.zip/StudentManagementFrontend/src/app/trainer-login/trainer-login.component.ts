import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Trainer } from '../trainer';
import { TrainerService } from '../trainer.service';

@Component({
  selector: 'app-trainer-login',
  templateUrl: './trainer-login.component.html',
  styleUrls: ['./trainer-login.component.css']
})
export class TrainerLoginComponent {
  trainer = new Trainer(0,"","","","","","");
  message=""
  trainerId: number=0;
  constructor(private trainerService:TrainerService,private router:Router){}

  trainerLogin()
{
this.trainerService.loginTrainer(this.trainer).subscribe((data:any)=>{console.log("Login Success"),
  console.log(data.trainerId),
  this.trainerId=data.trainerId},
  (error:any) =>{console.log("Login failed"),
  this.message="login failed. Enter valid email and password"}
)
}
back()
{
  this.router.navigate(['/welcomepage'])
}
}

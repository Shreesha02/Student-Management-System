import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-home',
  templateUrl: './student-home.component.html',
  styleUrls: ['./student-home.component.css']
})
export class StudentHomeComponent implements OnInit{
  studentId:number=0;
  constructor(private activatedroute:ActivatedRoute,private router:Router) { }
ngOnInit(): void {
  this.studentId=this.activatedroute.snapshot.params["studentId"];
}
studentProfile()
        {
          this.router.navigate(['/profile',this.studentId])
        }
viewcourseList(){
  this.router.navigate(['/viewcourseList',this.studentId])
}
  logOut()
  {
    this.router.navigate(['/welcomepage'])
  }
  contactUs()
  {
      this.router.navigate(['/contact'])
  }

}

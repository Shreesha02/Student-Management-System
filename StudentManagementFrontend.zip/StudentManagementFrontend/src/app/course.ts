export class Course{
    constructor(
     public courseId:number,
     public courseName:string,
	 public courseFees:string,
	 public courseDuration:string
     ){}
}
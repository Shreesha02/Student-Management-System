import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payment } from './payment';
import { Student } from './student';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private http:HttpClient) { }
  public getStudentDetails(_studentId:number):Observable<Student>
  {
    return this.http.get<Student>("http://localhost:8089/api/student/"+_studentId)
  }
  public addPayment(payment:Payment,studentId:number):Observable<any>
 {
   return this.http.post<any>("http://localhost:8089//api/payment/"+studentId,payment,{responseType:'text' as 'json'});
 }
 public getPaymentList():Observable<any>
  { 
    console.log("Get Payment");
    return  this.http.get<any>("http://localhost:8089/api/payment");
  }
 public getAllPayment():Observable<any>
 {
   return this.http.get<any>("http://localhost:8089/api/payment");
 }
 public getPaymentById(_paymentId:number):Observable<Payment>
{
  
  return this.http.get<Payment>("http://localhost:8089/api/payment");
}
 public getPaymentDetails(_paymentId:number):Observable<Payment>
 {
   return this.http.get<Payment>("http://localhost:8089/api/payment");
 }
}

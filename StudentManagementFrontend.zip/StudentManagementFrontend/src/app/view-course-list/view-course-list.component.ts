import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Course } from '../course';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-view-course-list',
  templateUrl: './view-course-list.component.html',
  styleUrls: ['./view-course-list.component.css']
})
export class ViewCourseListComponent implements OnInit{
  course = new Course(0,"","","");
  courseId:number=0;
  studentId:number=0;
  viewcourseList:any;
   constructor(private activatedroute:ActivatedRoute,private courseService:CourseService,private router:Router) { }
 
   ngOnInit(): void {
     this.getCourseList();
     this.studentId=this.activatedroute.snapshot.params["studentId"];
   }
   public getCourseList()
   {
      this.courseService.getCourseList().subscribe(data => {this.viewcourseList = data;});
   } 

   addPayment(studentId:number)
   {
    this.router.navigate(['/addPayment',studentId])
   }
   back()
  {
    this.router.navigate(['/studenthome',this.studentId])
  } 

  logOut()
  {
    this.router.navigate(['/welcomepage'])
  }
}

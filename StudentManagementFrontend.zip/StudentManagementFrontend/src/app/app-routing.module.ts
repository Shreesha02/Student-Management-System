import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminRegisterComponent } from './admin-register/admin-register.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { CourseListComponent } from './course-list/course-list.component';
import { CreateCourseComponent } from './create-course/create-course.component';
import { PaymentListComponent } from './payment-list/payment-list.component';
import { PaymentcontrollerComponent } from './paymentcontroller/paymentcontroller.component';
import { StudentHomeComponent } from './student-home/student-home.component';
import { StudentListComponent } from './student-list/student-list.component';
import { StudentLoginComponent } from './student-login/student-login.component';
import { StudentProfileComponent } from './student-profile/student-profile.component';

import { StudentRegisterComponent } from './student-register/student-register.component';
import { TrainerListComponent } from './trainer-list/trainer-list.component';
import { TrainerLoginComponent } from './trainer-login/trainer-login.component';
import { TrainercontrollerComponent } from './trainercontroller/trainercontroller.component';

import { UpdateCourseComponent } from './update-course/update-course.component';
import { ViewCourseListComponent } from './view-course-list/view-course-list.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [{ path: '', component:WelcomeComponent},
{ path: 'welcomepage', component:WelcomeComponent},
{ path: 'adminregister',component:AdminRegisterComponent},
{ path: 'adminlogin', component: AdminLoginComponent},
{ path: 'welcome', component: WelcomeComponent},
{ path: 'adminhome', component: AdminHomeComponent},
{ path: 'aboutus', component: AboutUsComponent},
{ path: 'contactus', component: ContactUsComponent},
{ path: 'studentlogin',component:StudentLoginComponent},
{ path: 'studentregister',component:StudentRegisterComponent},
{ path: 'studentlist',component:StudentListComponent},
{ path: 'studenthome/:studentId',component:StudentHomeComponent},
{ path: 'profile/:studentId',component:StudentProfileComponent},
{ path: 'courseList',component:CourseListComponent},
{ path: 'createCourse',component:CreateCourseComponent},
{ path: 'updateCourse/:courseId', component:UpdateCourseComponent},
{ path: 'trainerregister',component:TrainercontrollerComponent},
{ path: 'trainerlogin',component:TrainerLoginComponent},
{ path: 'trainerlist',component:TrainerListComponent},
{ path: 'paymentlist',component:PaymentListComponent},
{ path: 'addPayment',component:PaymentcontrollerComponent},
{ path: 'viewcourseList/:studentId',component:ViewCourseListComponent}
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

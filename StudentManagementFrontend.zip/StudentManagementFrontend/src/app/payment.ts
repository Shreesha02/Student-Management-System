export class Payment{
    constructor(
     public paymentId:number,
     public firstName:string,
	 public lastName:string,
     public courseName:string,
     public totalAmount:number
    ){}
}
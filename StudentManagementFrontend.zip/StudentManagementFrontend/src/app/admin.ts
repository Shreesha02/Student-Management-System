export class Admin{
    constructor(
        public adminId:number,
        public firstName:String,
        public lastName:String,
        public role:String,
        public adminEmailId:String,
        public adminPassword:String
    ){

    }
}